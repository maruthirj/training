package com.mydomain.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydomain.model.User;
import com.mydomain.service.UserManager;



@WebServlet("/AddEditServlet")
public class AddEditServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			User u = new User();
			if(request.getParameter("id")!=null)
			u.setId(Integer.parseInt(request.getParameter("id")));
			u.setName(request.getParameter("name"));
			u.setAge(Integer.parseInt(request.getParameter("age")));
			UserManager mgr = new UserManager();
			if(u.getId()==null){
				mgr.addUser(u);	
			}else{
				mgr.updateUser(u);
			}
			response.sendRedirect("listServlet");
		}catch(Exception e){
			throw new ServletException(e);
		}
		
	}

}

package com.mydomain.biz;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.mydomain.model.Products;

public class EnversTest {
	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
        ServiceRegistry serviceRegistry
            = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties()).build();
       SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
       Session ses = sessionFactory.openSession();
       Transaction tx = ses.beginTransaction();
//       Products p = new Products();
//       p.setProductName("Vanilla Ice Cream");
//       p.setProductPrice(new BigDecimal(10.5).setScale(2, RoundingMode.HALF_UP));
//       p.setStock(10);
//       p.setVersion(0);
//       ses.save(p);
       Products p = (Products)ses.load(Products.class, 1);
       p.setProductPrice(new BigDecimal(20.5).setScale(2, RoundingMode.HALF_UP));
       tx.commit();
       ses.close();
	}
}

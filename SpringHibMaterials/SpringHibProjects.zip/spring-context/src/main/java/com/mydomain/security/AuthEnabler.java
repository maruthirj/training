package com.mydomain.security;

import java.lang.reflect.Method;

/**
 * Interface that allows authentication checking
 * 
 * @author maruthir
 *
 */
public interface AuthEnabler {
	public Object secureInvoke(Method m, String user, String password, Object[] args);
}

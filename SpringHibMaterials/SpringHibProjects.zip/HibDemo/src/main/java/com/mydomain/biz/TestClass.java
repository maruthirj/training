package com.mydomain.biz;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;

import com.mydomain.model.Users;

public class TestClass {
	public static void main(String[] args) throws Exception{
		 Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
         ServiceRegistry serviceRegistry
             = new StandardServiceRegistryBuilder()
                 .applySettings(configuration.getProperties()).build();
          
         // builds a session factory from the service registry
        SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		 
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

//		List<Users> users = session.createQuery("select u from Users u").list();
//		System.out.println("Loaded users...");
//		for (Users user : users) {
//			System.out.println(user.getOrders());
//		}
		
		
//		List<Orders> orders = session.createQuery("select o from Orders o").list();
//		System.out.println("Loaded orders...");
//		for (Orders order : orders) {
//			System.out.println(order.getUser());
//		}
		
		
		
		
//		
//		Criteria crit = session.createCriteria(Users.class);
//		crit.setFetchMode("orders", FetchMode.JOIN);
//		crit.add(Restrictions.eq("id",307));
//		Users u = (Users)crit.uniqueResult();
//		System.out.println("Loaded user...");
//		System.out.println(u.getOrders().size());
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		Users user = (Users) session.load(Users.class, 309);
		System.out.println("User loaded: "+user.getClass().getName());
//		System.out.println(user.getName());
//		user.setName("Vinay");
		
		tx.commit();
		session.close();

		
		Session session2 = sessionFactory.openSession();
		Transaction tx2 = session2.beginTransaction();

		
		Users user2 = (Users) session2.load(Users.class, 309);
		System.out.println("User loaded");
		System.out.println(user2.getName());
		tx2.commit();
		session2.close();

		
		System.out.println("Done");
	}
}

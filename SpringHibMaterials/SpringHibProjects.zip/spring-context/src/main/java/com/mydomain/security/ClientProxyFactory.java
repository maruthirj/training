package com.mydomain.security;

import org.springframework.beans.factory.FactoryBean;

public class ClientProxyFactory implements FactoryBean {

	//Secure bean that needs proxying to pass the security info
	Object secureBean;
	
	public Object getSecureBean() {
		return secureBean;
	}

	public void setSecureBean(Object secureBean) {
		this.secureBean = secureBean;
	}

	@Override
	public Object getObject() throws Exception {
		return ClientProxyImpl.newInstance(secureBean);
	}

	@Override
	public Class getObjectType() {
		return null;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

}

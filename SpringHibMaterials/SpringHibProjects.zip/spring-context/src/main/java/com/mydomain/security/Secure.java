package com.mydomain.security;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Put this annotation to make beans secure
 * @author maruthir
 *
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface Secure {

}

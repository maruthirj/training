package com.mydomain.security;

/**
 * Marker interface alternative to @Secure annotation
 * @author maruthir
 *
 */
public interface Secureable {

}

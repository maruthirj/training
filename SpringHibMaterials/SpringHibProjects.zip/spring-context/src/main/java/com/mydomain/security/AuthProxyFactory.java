package com.mydomain.security;

import org.springframework.beans.factory.FactoryBean;

public class AuthProxyFactory implements FactoryBean {

	//Secure bean that needs proxying to pass the security info
	Object beanToSecure;
	
	
	public Object getBeanToSecure() {
		return beanToSecure;
	}

	public void setBeanToSecure(Object beanToSecure) {
		this.beanToSecure = beanToSecure;
	}

	@Override
	public Object getObject() throws Exception {
		return AuthProxyImpl.newInstance(beanToSecure);
	}

	@Override
	public Class getObjectType() {
		return null;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

}

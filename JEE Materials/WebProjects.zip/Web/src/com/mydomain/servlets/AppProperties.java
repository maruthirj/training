package com.mydomain.servlets;

import java.util.ResourceBundle;

public class AppProperties {
	private static ResourceBundle bundle;
	static {
		bundle = ResourceBundle.getBundle("app");
	}

	public static String getString(String key) {
		return bundle.getString(key);
	}
}

package com.mydomain.servlets;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(
		urlPatterns = { "/LifeCycleServlet" }, 
		initParams = { 
				@WebInitParam(name = "plancks_constant", value = "6.62606957 × 10-34", description = "Plancks constant in string format")
		})
public class LifeCycleServlet extends HttpServlet {

	public void init(ServletConfig config) throws ServletException {
		System.out.println("Planck's constant is: "+getInitParameter("plancks_constant"));
	}

	public void destroy() {
		System.out.println("Done with the short life.. time to go!!");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Hello there! Good you thought of me!");
	}

}

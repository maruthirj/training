package com.mydomain.biz;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mydomain.model.User;
import com.mydomain.service.UserManagerRemote;

public class TestClass {
	public static void main(String[] args) throws Exception {
		ApplicationContext context =
			    new ClassPathXmlApplicationContext(new String[] {"application-context.xml"});
		UserManager mgr = (UserManager)context.getBean(UserManager.class);
		mgr = (UserManager)context.getBean("userManager");
		System.out.println(mgr);
		List<User> users = mgr.getAllUsers();

		UserManagerRemote remoteHttp = (UserManagerRemote)context.getBean("userManagerRemote");
		users = remoteHttp.getAllUsers();
		System.out.println("Remote data: "+ users);
		
		//Test Secure Bean
//		UserDao dao = (UserDao)context.getBean("authenticatedDao");
//		dao.getAllUsers();
		
	}
}

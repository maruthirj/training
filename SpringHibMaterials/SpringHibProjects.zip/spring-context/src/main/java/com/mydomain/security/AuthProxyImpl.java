package com.mydomain.security;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.mydomain.dao.UserDao;
import com.mydomain.dao.UserDaoImpl;

/**
 * Proxy implementation that calls the original method by passing the security context info
 * @author maruthir
 *
 */
public class AuthProxyImpl implements java.lang.reflect.InvocationHandler {

	private Object obj;

	public static Object newInstance(Object obj) {
		//Get this proxy to implement methods of the target plus the authenabler interface
		List<Class> interfaces = new ArrayList(Arrays.asList(obj.getClass().getInterfaces()));
		interfaces.add(AuthEnabler.class);
		Class[] classArr = interfaces.toArray(new Class[1]);
		return java.lang.reflect.Proxy.newProxyInstance(obj.getClass()
				.getClassLoader(), classArr,
				new AuthProxyImpl(obj));
	}

	private AuthProxyImpl(Object obj) {
		this.obj = obj;
	}

	public Object invoke(Object proxy, Method m, Object[] args)
			throws Throwable {
		try {
			if(m.getName().equals("secureInvoke")){
				//Perform auth and call the target method
				Method targetMethod = (Method)args[0];
				String user = (String)args[1];
				String pass = (String)args[2];
				if(user.equals("admin") && pass.equals("admin123")){
					Object[] methodArgs = Arrays.copyOfRange(args, 3, args.length-1);
					return targetMethod.invoke(obj, methodArgs);	
				}else{
					throw new Exception("Authentication info denied");
				}
			}else{
				//Direct method invocation - prevent it unless its for any setter method
					throw new Exception("Authentication info not provided");
			}
		} catch (Exception e) {
			throw new RuntimeException("unexpected invocation exception: "
					+ e.getMessage());
		}
	}
	
	public static void main(String[] args) throws Exception {
		//UserDaoImpl daoImpl = new UserDaoImpl();
		//UserDao secureDao = (UserDao)AuthProxyImpl.newInstance(daoImpl);
		
		//UserDao authEnabledClient = (UserDao)ClientProxyImpl.newInstance(secureDao);
		//System.out.println(authEnabledClient.getAllUsers());
	}

}

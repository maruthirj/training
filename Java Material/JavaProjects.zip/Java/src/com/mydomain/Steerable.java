package com.mydomain;

public interface Steerable {
	void turnRight();
	void turnLeft();
}


package com.mydomain.biz;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.mydomain.model.Products;

public class VersionTest {
	public static void main(String[] args) {
		 Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
         ServiceRegistry serviceRegistry
             = new StandardServiceRegistryBuilder()
                 .applySettings(configuration.getProperties()).build();
          
         // builds a session factory from the service registry
        SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		 
//		Session s1 = sessionFactory.openSession();
//		Session s2 = sessionFactory.openSession();
//		Transaction t1 = s1.beginTransaction();
//		Transaction t2 = s2.beginTransaction();
//		Products p1 = (Products)s1.createQuery("select p from Products p where id=3").uniqueResult();
//		System.out.println("Reading p2");
//		Products p2 = (Products)s2.createQuery("select p from Products p where id=3").uniqueResult();
//		p1.setProductPrice(new BigDecimal(10.1).setScale(2, RoundingMode.HALF_UP));
//		p2.setProductPrice(new BigDecimal(10.2).setScale(2, RoundingMode.HALF_UP));
//		System.out.println("Saving p1");
//		s1.save(p1);
//		System.out.println("Saving p2");
//		s2.save(p2);
//		System.out.println("Committing t1");
//		t1.commit();
//		System.out.println("Committing t2");
//		t2.commit();
//		s1.close();
//		s2.close();
//		System.out.println("Done");
		
		
		Session s1 = sessionFactory.openSession();
		Session s2 = sessionFactory.openSession();
		Transaction t1 = s1.beginTransaction();
		Transaction t2 = s2.beginTransaction();
		List<Products> prods1 = s1.createQuery("select p from Products p").list();
		System.out.println("Reading p2");
		List<Products> prods2 = s2.createQuery("select p from Products p").list();
		Products p = new Products();
		p.setProductName("Vanilla Ice Cream");
		p.setProductPrice(new BigDecimal(10.1).setScale(2, RoundingMode.HALF_UP));
		p.setStock(2);
		System.out.println("Saving new product");
		s1.save(p);
		System.out.println("Committing t1");
		t1.commit();
		System.out.println("Committing t2");
		t2.commit();
		s1.close();
		s2.close();
		System.out.println("Done");

	}
}

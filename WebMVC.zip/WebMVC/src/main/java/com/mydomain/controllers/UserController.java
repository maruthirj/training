package com.mydomain.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mydomain.dao.UserDao;
import com.mydomain.model.User;

@Controller
public class UserController {
	
	@Autowired
	UserDao userDao;
	
	@RequestMapping("/userForm")
	public String showUserForm(HttpServletRequest req){
		return "UserForm";
	}
	
    @RequestMapping("/addUser")
    public String addUser(User u, Model model) throws Exception {
    	userDao.addUser(u);
        model.addAttribute("message", "Added User!");
        return "helloWorld";
    }
    
}
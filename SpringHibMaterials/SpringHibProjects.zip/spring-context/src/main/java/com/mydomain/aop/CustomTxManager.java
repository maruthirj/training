package com.mydomain.aop;

import java.sql.Connection;
import java.sql.DriverManager;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class CustomTxManager {

	public static ThreadLocal<Connection> threadLocalConnections = new ThreadLocal<Connection>();
	
	String connectionUrl;
	
	String driverClass;
	
	public String getConnectionUrl() {
		return connectionUrl;
	}
	public void setConnectionUrl(String connectionUrl) {
		this.connectionUrl = connectionUrl;
	}
	public String getDriverClass() {
		return driverClass;
	}
	public void setDriverClass(String driverClass) {
		this.driverClass = driverClass;
	}
	
	private Connection getConnection() throws Exception{
		Class.forName(driverClass);
		return DriverManager.getConnection(connectionUrl);
	}


	@Around("execution(* getAll*(..))")
    public Object startTransactions(ProceedingJoinPoint pjp) throws Throwable {
		System.out.println("Starting transaction...");
		Connection con = getConnection();
		con.setAutoCommit(false);
		Object result=null;
		try{
			threadLocalConnections.set(con);
			result = pjp.proceed();
			con.commit();
		}finally{
			threadLocalConnections.get().close();			
		}
		return result;
	}
}

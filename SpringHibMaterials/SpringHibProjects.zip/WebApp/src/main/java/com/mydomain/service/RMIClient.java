package com.mydomain.service;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;

import com.mydomain.model.User;

public class RMIClient {
	public static void main(String[] args) throws Exception{
		String name = "UserManager";
		Registry registry = LocateRegistry.getRegistry("localhost",1199);
		UserManagerRemote um = (UserManagerRemote) registry.lookup(name);
		System.out.println(um);
		List<User> users = um.getAllUsers();
		System.out.println(users);

	}
}

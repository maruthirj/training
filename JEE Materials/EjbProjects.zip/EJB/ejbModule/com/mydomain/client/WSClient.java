package com.mydomain.client;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.mydomain.CalculatorRemote;

public class WSClient {

	public static void main(String[] args) throws Exception {

		URL url = new URL("http://localhost:8080/EJB/Calculator?wsdl");

		// 1st argument service target namespace, refer to wsdl document above
		// 2nd argument is service name, refer to wsdl document above
		QName qname = new QName("http://mydomain.com/","CalculatorService");

		Service service = Service.create(url, qname);

		CalculatorRemote calc = service.getPort(CalculatorRemote.class);

		System.out.println(calc.findAllUsers());
	}
}

package com.mydomain;

import javax.ejb.Local;

@Local
public interface CalculatorLocal {
	Integer add(int i, int j);
}

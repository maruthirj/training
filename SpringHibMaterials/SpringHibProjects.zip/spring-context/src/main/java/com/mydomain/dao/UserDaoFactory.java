package com.mydomain.dao;

public class UserDaoFactory {
//	public  UserDao getDao(){
//		//return new UserDaoImpl();
//	}
}

package com.mydomain.aop;

import java.sql.Connection;

import org.springframework.beans.factory.FactoryBean;

public class CustomTxConnectionFactory implements FactoryBean<Connection>{

	@Override
	public Connection getObject() throws Exception {
		System.out.println("Getting connection from tx manager");
		return CustomTxManager.threadLocalConnections.get();
	}

	@Override
	public Class<?> getObjectType() {
		return Connection.class;
	}

	@Override
	public boolean isSingleton() {
		return false;
	}

}

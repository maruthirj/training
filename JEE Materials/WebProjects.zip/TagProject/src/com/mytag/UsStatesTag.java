package com.mytag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class UsStatesTag extends SimpleTagSupport {

	private String name="states";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void doTag() throws JspException, IOException {
		
		String selectTag = "<select name='"+name+"'><option value='GA'>Georgia</option><option value='CA'>California</option></select>";
		getJspContext().getOut().println(selectTag);
	}
}

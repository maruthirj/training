package com.mydomain;

import java.util.Collections;
import java.util.List;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;
import org.jgroups.Address;
import org.jgroups.Channel;
import org.jgroups.JChannel;
import org.jgroups.util.UUID;

public class ZooKeeperLeaderElection {
	public static Address leader;
	public static boolean amLeader = false;

	public static void main(String[] args) throws Exception {
		System.setProperty("jgroups.bind_addr","127.0.0.1");
		System.setProperty("java.net.preferIPv4Stack","true");
		System.setProperty("jgroups.udp.mcast_addr","224.0.0.0");
		
		System.out.println(System.getProperty("jgroups.bind_addr"));
		JChannel channel = new JChannel(); // use the default config, udp.xml
		channel.connect("ServiceNodesCluster");

		// Connect to zookeeper
		ZooKeeper zk = new ZooKeeper("localhost:2181,localhost:2182,localhost:2183", 10000, watchedEvent -> {
			if( watchedEvent.getState() == KeeperState.Disconnected) {
				System.out.println("Disconnected");
			}
			System.out.println("Watched event path: " + watchedEvent.getPath());
			System.out.println("Watched event: " + watchedEvent);
		});
		// Make sure root node exists for leader election
		if (zk.exists("/ELECTION", false) == null) {
			try {
				zk.create("/ELECTION", "Main election znode".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE,
						CreateMode.PERSISTENT);
			} catch (KeeperException k) {
				System.out.println("Error: " + k.getMessage());
				// Probably already exists. Skip
			}
		}
		String createdNode=null;
		int ourNodeSequence=0;
		try {
			createdNode = zk.create("/ELECTION/node_", ((UUID) channel.getAddress()).toStringLong().getBytes(),
					ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);
			ourNodeSequence = Integer.parseInt(createdNode.split("_")[1]);
		} catch (KeeperException | InterruptedException e1) {
			e1.printStackTrace();
		}
		System.out.println("Current node sequence: " + ourNodeSequence);
		while (true) {
			try {
				List<String> children = zk.getChildren("/ELECTION", false);
				Collections.sort(children);
				// Set a watch on the highest node below this node
				int highestNodeSeq = 0;
				for (String child : children) {
					Integer nodeSeq = Integer.parseInt(child.split("_")[1]);
					if (highestNodeSeq <= nodeSeq) {
						highestNodeSeq = nodeSeq;
					} else
						break;
				}
				System.out.println("Our node seq: " + ourNodeSequence + " Highest node seq: " + highestNodeSeq);
				if (highestNodeSeq != 0 && highestNodeSeq != ourNodeSequence) {
					// Some other node is the leader. Set a watch for him and
					// store his address
					amLeader = false;
					byte[] leaderData = zk.getData("/ELECTION/node_" + String.format("%010d", highestNodeSeq),
							watchEvent -> {
								if (watchEvent.getType().equals(EventType.NodeDeleted)) {
									// Leader disappeared.
									System.out.println("Leader disappeared: " + watchEvent.getPath());
									leader = null;
								}
							} , new Stat());
					leader = UUID.fromString(new String(leaderData));
				} else if (highestNodeSeq == ourNodeSequence) {
					// This node is the leader
					System.out.println("I am leader");
					amLeader = true;
					leader = null;
				}
				Thread.sleep(2000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
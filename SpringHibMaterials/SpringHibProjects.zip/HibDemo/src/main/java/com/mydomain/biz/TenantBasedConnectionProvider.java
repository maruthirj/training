package com.mydomain.biz;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;

public class TenantBasedConnectionProvider implements MultiTenantConnectionProvider{

	public boolean isUnwrappableAs(Class arg0) {
		return false;
	}

	public <T> T unwrap(Class<T> arg0) {
		return null;
	}

	public Connection getAnyConnection() throws SQLException {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			return DriverManager.getConnection("jdbc:derby://localhost:1527//Users/maruthir/Documents/Training/workspace/CRUD/WebContent/WEB-INF/mydb");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new SQLException("Cannot load driver class: "+e.getMessage());
		}
	}

	public Connection getConnection(String tenantName) throws SQLException {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			return DriverManager.getConnection("jdbc:derby://localhost:1527//Users/maruthir/Documents/Training/workspace/CRUD/WebContent/WEB-INF/"+tenantName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new SQLException("Cannot load driver class: "+e.getMessage());
		}
	}

	public void releaseAnyConnection(Connection con) throws SQLException {
		con.close();
	}

	public void releaseConnection(String tenantName, Connection con)
			throws SQLException {
		con.close();
	}

	public boolean supportsAggressiveRelease() {
		return false;
	}

}

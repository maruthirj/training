package com.mydomain.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydomain.model.User;
import com.mydomain.service.UserManager;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		try {
			UserManager um = new UserManager();
			User u = um.doesUserExist(name);
			if (u != null) {
				request.getSession().setAttribute("user", u);
				response.sendRedirect("listServlet");
			}else{
				response.sendRedirect("loginPage.jsp");
			}
		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

}

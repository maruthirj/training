package com.mydomain.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mydomain.dao.UserDao;
import com.mydomain.model.User;

@Component
public class UserManager {

	//@Resource(name="authenticatedDao")
	@Autowired
	private UserDao dao;

	public UserDao getDao() {
		return dao;
	}

	public void setDao(UserDao dao) {
		this.dao = dao;
	}

	public List<User> getAllUsers() throws Exception {
		return dao.getAllUsers();
	}

}


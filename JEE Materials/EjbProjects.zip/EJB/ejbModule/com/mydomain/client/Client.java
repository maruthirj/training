package com.mydomain.client;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Properties;

import javax.ejb.TimerHandle;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.mydomain.Calculator;
import com.mydomain.CalculatorRemote;

public class Client {

	public static void main(String[] args) throws Exception {
		final Hashtable jndiProperties = new Hashtable();
		jndiProperties.put(Context.URL_PKG_PREFIXES,
				"org.jboss.ejb.client.naming");
		final Context context = new InitialContext(jndiProperties);
//		final String appName = "";
//		final String moduleName = "EJB";
//		final String distinctName = "";
//		final String beanName = Calculator.class.getSimpleName();
//		final String viewClassName = CalculatorRemote.class.getName();
//		String lookupName = "ejb:" + appName + "/" + moduleName + "/"
//				+ distinctName + "/" + beanName + "!" + viewClassName;
//		System.out.println(lookupName);
		CalculatorRemote remote = (CalculatorRemote) context.lookup("ejb:/EJB//Calculator!com.mydomain.CalculatorRemote");
		System.out.println("Sum = " + remote.add(3, 5));
//		System.out.println("Users: "+remote.findAllUsers());
//		remote.createTimer();
//		System.out.println("Timer created...");
//		System.out.println("Timer cancelled...");
//		init(context, "email_events");
//		sendMsg();
	}

	public final static String QUEUE_NAME = "queue/email_events";

	private static QueueConnectionFactory qconFactory;
	private static QueueConnection qcon;
	private static QueueSession qsession;
	private static QueueSender qsender;
	private static Queue queue;
	private static TextMessage msg;

	public static void init(Context ctx, String queueName) throws NamingException,
			JMSException {
		qconFactory = (QueueConnectionFactory) ctx.lookup("jms/RemoteConnectionFactory");
		qcon = qconFactory.createQueueConnection();
		qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
		queue = (Queue) ctx.lookup(queueName);
		qsender = qsession.createSender(queue);
		msg = qsession.createTextMessage();
		qcon.start();
	}

	private static void sendMsg() throws IOException, JMSException {
		System.out.println("Following Messages has been sent !!!");
		System.out.println("====================================");
		for (int j = 1; j <= 3; j++) {
			msg.setText("" + j); // Messages
			qsender.send(msg); // Messages sent
			System.out.println("Message Sent = " + j);
		}
		System.out.println("====================================");
	}
}

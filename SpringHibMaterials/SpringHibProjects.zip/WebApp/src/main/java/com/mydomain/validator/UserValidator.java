package com.mydomain.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.mydomain.model.User;

public class UserValidator implements Validator{

	public boolean supports(Class<?> cls) {
		return User.class==cls;
	}

	public void validate(Object obj, Errors err) {
		User u = (User)obj;
		System.out.println("Validating user: "+u);
		ValidationUtils.rejectIfEmptyOrWhitespace(err, "name", "field.required", "Field Name is required");
		ValidationUtils.rejectIfEmpty(err, "age", "field.required", "Field Age is required");
	}

}

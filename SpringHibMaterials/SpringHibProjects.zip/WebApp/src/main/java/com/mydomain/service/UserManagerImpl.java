package com.mydomain.service;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
import org.springframework.stereotype.Component;

import com.mydomain.model.Orders;
import com.mydomain.model.User;

public class UserManagerImpl extends HibernateDaoSupport implements UserManager, UserManagerRemote, ApplicationContextAware {

	
	@Autowired
	private DataSource dataSource;
	

	// private static Connection con;
	// static {
	// try {
	// Class.forName("org.apache.derby.jdbc.ClientDriver");
	// con =
	// DriverManager.getConnection("jdbc:derby://localhost:1527//Users/maruthir/Documents/Training/workspace/CRUD/WebContent/WEB-INF/mydb");
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

	public User doesUserExist(String name) throws Exception {
		Statement statement = dataSource.getConnection().createStatement();
		ResultSet rs = statement
				.executeQuery("select * from users where name='" + name + "'");
		if (rs.next()) {
			User u = new User();
			u.setId(rs.getInt("id"));
			u.setAge(rs.getInt("age"));
			u.setEmailId(rs.getString("email_id"));
			u.setJoinDate(rs.getDate("join_date"));
			u.setName(rs.getString("name"));
			u.setPassword(rs.getString("password"));
			u.setState(rs.getString("state"));
			return u;
		}
		return null;
	}

	

	public User getUser(Integer id) throws Exception {
		Statement statement = dataSource.getConnection().createStatement();
		ResultSet rs = statement.executeQuery("select * from users where id="
				+ id);
		while (rs.next()) {
			User u = new User();
			u.setId(rs.getInt("id"));
			u.setAge(rs.getInt("age"));
			u.setEmailId(rs.getString("email_id"));
			u.setJoinDate(rs.getDate("join_date"));
			u.setName(rs.getString("name"));
			u.setPassword(rs.getString("password"));
			u.setState(rs.getString("state"));
			return u;
		}
		return null;// User not found
	}

	public void addUser(User u) throws Exception {
		Statement st = dataSource.getConnection().createStatement();
		st.execute("insert into users (name,age) values ('" + u.getName()
				+ "'," + u.getAge() + ")");
	}

	public void updateUser(User u) throws Exception {
		Statement st = dataSource.getConnection().createStatement();
		st.execute("update users set name='" + u.getName() + "', age="
				+ u.getAge() + " where id=" + u.getId());
	}

	public void deleteUser(Integer id) throws Exception {
		Statement st = dataSource.getConnection().createStatement();
		st.execute("delete from users where id=" + id);
	}

	public List<User> getAllUsers() throws Exception {
		Session ses = getSessionFactory().getCurrentSession();
		List<User> users = ses.createQuery("select u from User u").list();
		return users;
	}
	
	public void generateOrders() throws Exception {
		System.out.println("Getting all users...");
		List<User> users = getAllUsers();
		for (User user : users) {
			try{
				System.out.println("Generating order for user: "+user.getName());
				UserManager um = (UserManager)ctx.getBean("userManager");
				um.generateOrder(user);
				//generateOrder(user);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}

	public void generateOrder(User u) throws Exception {
		Session ses = getSessionFactory().getCurrentSession();
		//u = (User)ses.load(User.class, u.getId()); 
		if(u.getName().equals("admin")){
			throw new RuntimeException("Admin cannot have orders");
		}
		System.out.println("Generating order for user: "+u.getName());
		Orders o = new Orders();
		o.setShipToAddress("Bangalore");
		o.setOrderValue(300);
		o.setUserId(u.getId());
		u.getOrders().add(o);
		
		ses.save(o);
	}

	
	ApplicationContext ctx;
	public void setApplicationContext(ApplicationContext arg0)
			throws BeansException {
		ctx = arg0;
	}
}

package com.mydomain.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydomain.ejb.UserManagerLocal;
import com.mydomain.model.User;



@WebServlet("/loadForEditServlet")
public class LoadForEditServlet extends HttpServlet {
	
	@EJB
	UserManagerLocal userManager;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			Integer id = Integer.parseInt(request.getParameter("id"));
			User u = userManager.getUser(id);
			request.setAttribute("user", u);
			request.getRequestDispatcher("UserForm.jsp").forward(request, response);
		}catch(Exception e){
			throw new ServletException(e);
		}
		
	}

}

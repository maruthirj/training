package com.mydomain.biz;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.mydomain.model.Users;

public class MultiTenantTest {
	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
        ServiceRegistry serviceRegistry
            = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties()).build();
         
        // builds a session factory from the service registry
       SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
       Session ses = sessionFactory.withOptions().tenantIdentifier("mydb").openSession();
       List<Users> users = ses.createQuery("select u from Users u").list();
       System.out.println(users);
       ses.close();
	}
}

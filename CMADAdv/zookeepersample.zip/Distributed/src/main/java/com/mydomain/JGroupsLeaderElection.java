package com.mydomain;

import org.jgroups.Address;
import org.jgroups.Channel;
import org.jgroups.JChannel;
import org.jgroups.Message;
import org.jgroups.ReceiverAdapter;

public class JGroupsLeaderElection extends ReceiverAdapter implements Runnable {
	private Channel channel;
	private Boolean leaderResponded;
	public static Address leader;
	public static boolean amLeader = false;

	public JGroupsLeaderElection(Channel channel) {
		this.channel = channel;
		leaderResponded = false;
	}

	@Override
	public void receive(Message msg) {
		Object data = msg.getObject();
		if (data instanceof String) {
			String message = (String) data;
			if (!message.startsWith("Leader"))
				return;
			if (message.split("::")[1].equals("response")) {
				//If this is leader response
				leader = msg.getSrc();
				System.out.println(channel.getAddress()
						+ " setting leader to: "
						+ leader);
				leaderResponded = true;
			}
			if (message.split("::")[1].equals("ping")
					&& amLeader) {
				// Sending a response from leader
				Message m = new Message(null, null, "Leader::response");
				try {
					channel.send(m);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void run() {
		try {
			channel.setReceiver(this);
			Message m = new Message(null, null, "Leader::ping");
			channel.send(m);
			Thread.sleep(3000);
			while (true) {
				if (leaderResponded != null && leaderResponded) {
					leaderResponded = false;
					m = new Message(null, null, "Leader::ping");
					channel.send(m);
					Thread.sleep(3000);
				} else {
					// Become the leader
					System.out.println(channel.getAddress()
							+ " Is the Leader ******");
					amLeader = true;
					m = new Message(null, null, "Leader::response");
					channel.send(m);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws Exception{
		System.setProperty("jgroups.bind_addr","127.0.0.1");
		System.setProperty("java.net.preferIPv4Stack","true");
		System.setProperty("jgroups.udp.mcast_addr","224.0.0.0");
		
		System.out.println(System.getProperty("jgroups.bind_addr"));
		JChannel channel = new JChannel(); // use the default config, udp.xml
		channel.connect("ServiceNodesCluster");
		JGroupsLeaderElection js = new JGroupsLeaderElection(channel);
		channel.setReceiver(js);
		new Thread(js).start();
	}
}
package com.mydomain.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/WizardServlet1")
public class WizardServlet1 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String respStr = "<form action='WizardServlet2'><input type='hidden' name='name' value='"+name+"'/><input type='hidden' name='address' value='"+address+"'/>Phone: <input type='text' name='phone'/><br>Email: <input type='text' name='email'/><br><input type='submit' value='finish'/></form>";
		response.getWriter().print(respStr);
	}
}

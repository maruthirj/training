package com.mydomain.security;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * Wrap all bean instances in auth proxy
 * 
 * @author maruthir
 *
 */
public class SecurityBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
		if (bean.getClass().isAnnotationPresent(Secure.class) ) {
			return AuthProxyImpl.newInstance(bean);
		} else {
			return bean;
		}
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName)
			throws BeansException {
		return bean;
	}
}

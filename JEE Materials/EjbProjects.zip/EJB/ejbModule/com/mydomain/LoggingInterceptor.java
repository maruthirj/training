package com.mydomain;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class LoggingInterceptor {
	@AroundInvoke
	public Object methodInterceptor(InvocationContext ctx) throws Exception {
		System.out.println("*** Method invoked: "+ ctx.getMethod().getName());
		return ctx.proceed();
	}
}

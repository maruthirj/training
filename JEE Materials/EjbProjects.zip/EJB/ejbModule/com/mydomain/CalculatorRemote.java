package com.mydomain;

import java.util.List;

import javax.ejb.Remote;
import javax.jws.WebMethod;
import javax.jws.WebService;

@Remote
@WebService
public interface CalculatorRemote {
	Integer add(int i, int j);
	@WebMethod
	List<User> findAllUsers();
	void createTimer();
}

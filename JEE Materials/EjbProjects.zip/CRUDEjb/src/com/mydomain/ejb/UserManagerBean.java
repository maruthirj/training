package com.mydomain.ejb;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import com.mydomain.model.User;

/**
 * Session Bean implementation class UserManagerBean
 */
@Stateless
public class UserManagerBean implements UserManagerLocal {

	@PersistenceContext(unitName="UserPU")
    protected EntityManager em;
	
	private static Connection con;
	static {
		try {
			// Class.forName("org.apache.derby.jdbc.ClientDriver");
			// con =
			// DriverManager.getConnection("jdbc:derby://localhost:1527//Users/maruthir/Documents/Training/workspace/CRUD/WebContent/WEB-INF/mydb");
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/DerbyDS");
			con = ds.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private Connection getConnection2() throws Exception{
		InitialContext ic = new InitialContext();
		DataSource ds = (DataSource) ic.lookup("java:/DerbyOtherDS");
		return ds.getConnection();
	}
	
	public List<User> getAllUsers() throws Exception {
		System.out.println("Loading users via JPA");
		Query q = em.createNamedQuery("AllUsers");
        List<User> userList = q.getResultList();
        return userList;
        
//		Statement statement = con.createStatement();
//		ResultSet rs = statement.executeQuery("select * from users");
//		List<User> users = new ArrayList<User>();
//		while (rs.next()) {
//			User u = new User();
//			u.setId(rs.getInt("id"));
//			u.setAge(rs.getInt("age"));
//			u.setEmailId(rs.getString("email_id"));
//			u.setJoinDate(rs.getDate("join_date"));
//			u.setName(rs.getString("name"));
//			u.setPassword(rs.getString("password"));
//			u.setState(rs.getString("state"));
//			users.add(u);
//		}
//		return users;
	}

	public User getUser(Integer id) throws Exception {
		Statement statement = con.createStatement();
		ResultSet rs = statement.executeQuery("select * from users where id="
				+ id);
		while (rs.next()) {
			User u = new User();
			u.setId(rs.getInt("id"));
			u.setAge(rs.getInt("age"));
			u.setEmailId(rs.getString("email_id"));
			u.setJoinDate(rs.getDate("join_date"));
			u.setName(rs.getString("name"));
			u.setPassword(rs.getString("password"));
			u.setState(rs.getString("state"));
			return u;
		}
		return null;// User not found
	}

	public void addUser(User u) throws Exception {
		Statement st = con.createStatement();
		st.execute("insert into users (name,age) values ('" + u.getName()
				+ "'," + u.getAge() + ")");
	}

	public void updateUser(User u) throws Exception {
		Statement st = con.createStatement();
		st.execute("update users set name='" + u.getName() + "', age="
				+ u.getAge() + " where id=" + u.getId());
	}

	public void deleteUser(Integer id) throws Exception {
		Statement st = con.createStatement();
		st.execute("delete from users where id=" + id);
	}

	public void deleteUsers(List<Integer> ids) throws Exception {
		Statement st = con.createStatement();
		String idsStr = ids.toString().replaceAll("\\[", "")
				.replaceAll("\\]", "");
		String delQuery = "delete from users where id in (" + idsStr + ")";
		System.out.println("Del query = " + delQuery);
		st.execute(delQuery);
	}

	@EJB
	UserManagerLocal userManager;
	
	public void generateOrders() throws Exception {
		List<User> users = getAllUsers();
		for (User user : users) {
			try {
				generateOrder(user);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	@Asynchronous
	public Future<Integer> generateOrdersAsync() throws Exception {
		List<User> users = getAllUsers();
		for (User user : users) {
			try {
				generateOrder(user);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("Async operation generateOrdersAsync completed");
		return new AsyncResult<Integer>(users.size());
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void generateOrder(User u) throws Exception {
		for(int i=0; i<5; i++){
			String orderCreateQuery = "insert into orders (ship_to_address,order_value, user_id) values ('Bangalore',300,"
					+ u.getId() + ")";
			Statement st = con.createStatement();
			st.execute(orderCreateQuery);
		}
	}
	
	private void createUser(Connection con, User u) throws Exception{
		Statement st = con.createStatement();
		String insertSql = "insert into users (name,age) values ('"+u.getName()+"',"+u.getAge()+")";
		st.execute(insertSql);
	}
	
	@Resource
	SessionContext ctx;
	
	
	public void transferUser(Integer id) throws Exception{
		Connection con2 = getConnection2();
		try{
			User u = getUser(id);
			createUser(con2, u);
			deleteUser(id);
		}catch(Exception e){
			ctx.setRollbackOnly();
			throw e;
		}finally{
			//Return connection to pool
			con2.close();
		}
	}
}

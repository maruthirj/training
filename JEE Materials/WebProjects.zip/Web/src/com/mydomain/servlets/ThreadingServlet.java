package com.mydomain.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ThreadingServlet")
public class ThreadingServlet extends HttpServlet {
	private String name ="";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		name = request.getParameter("name");
		for (int i = 0; i< 1000; i++){
			//Just a dummy loop to represent some business logic
			System.out.println("Thread: "+Thread.currentThread().getName());
		}
		response.getWriter().print("Hello "+name);
	}

}

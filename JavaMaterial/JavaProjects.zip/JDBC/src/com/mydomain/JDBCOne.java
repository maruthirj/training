package com.mydomain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

@DBConfig(hostName="localhost", portNumber="3306")
public class JDBCOne {
	public static void main(String[] args) throws Exception {
		DBConfig config = JDBCOne.class.getAnnotation(DBConfig.class);
		
		System.out.println("DB Host: "+config.hostName());
		Class.forName("com.mysql.jdbc.Driver");
		Connection mysqlcon = DriverManager.getConnection("jdbc:mysql://"+config.hostName()+":"+config.portNumber()+"/resellclear");
		
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		Connection con = DriverManager.getConnection("jdbc:derby:mydb;create=true");
		con.setAutoCommit(false);
		Statement st = con.createStatement();
		
		
		for(int i=0;i<5;i++){
			if(i==4)
				throw new Exception("Failing...");
			st.executeUpdate("insert into students (name,address) values ('Ganesh"+i+"','1 ABC Street ABC Bangalore')");
		}
		ResultSet rs = st.executeQuery("select * from students");
		ResultSetMetaData meta = rs.getMetaData();
		System.out.println(con);
		System.out.println(st);
		System.out.println(rs);
		int count = meta.getColumnCount();
		for(int i=1; i<= count; i++){
			System.out.print(meta.getColumnName(i)+" ");
		}
		System.out.println("\n-------------------------------------------");
		while(rs.next()){
			for(int i=1; i<= count; i++){
				System.out.print(rs.getString(i)+" ");
			}
			System.out.println("");
		}
			
		con.commit();
		con.close();
		
	}
}

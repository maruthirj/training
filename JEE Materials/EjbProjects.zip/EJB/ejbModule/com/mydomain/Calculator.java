package com.mydomain;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.ScheduleExpression;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.interceptor.Interceptors;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

/**
 * Session Bean implementation class Calculator
 */
@Stateless(mappedName = "Calc")
@LocalBean
@Interceptors({LoggingInterceptor.class})
@WebService
public class Calculator implements CalculatorRemote, CalculatorLocal {

	@PersistenceContext(unitName="UserPU")
    protected EntityManager em;
	
	@Resource
	private SessionContext context;
	
	public Integer add(int i, int j) {
		try{
			InitialContext ic = new InitialContext();
			DataSource ds =  (DataSource)ic.lookup("java:jboss/datasources/mysqlDS");
			Connection con = ds.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from user");
			while(rs.next()){
				System.out.println(rs.getString("name"));
			}
			con.close();
			List<User> users = findAllUsers();
			System.out.println("Users from db : "+users.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return i+j;
	}
	
	@WebMethod
	public List<User> findAllUsers() {
        Query q = em.createNamedQuery("AllUsers");
        List<User> userList = q.getResultList();
        return userList;
    }
	
	@Resource
	private SessionContext sctx;
	
	public void createTimer(){
		ScheduleExpression sc = new ScheduleExpression();
		sc.second("*/10");
		sc.minute("*");
		sc.hour("*");
		TimerConfig tc = new TimerConfig();
		tc.setPersistent(false);
		context.getTimerService().createCalendarTimer(sc,tc);
		System.out.println("Timer created...");
	}
	
	@Schedule(minute="*/1", hour="*", second="0", persistent=false)
	@Timeout
	public void timeoutMethod(Timer timer){
		System.out.println("Executing timed operation...");
	}
	
	
}

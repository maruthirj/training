CREATE TABLE users
(
	id INTEGER NOT NULL GENERATED 
	ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
	name varchar(100),
	email_id varchar(100) ,
	password varchar(100) ,
	join_date timestamp ,
	age int  ,
	state varchar(2) ,
	CONSTRAINT primary_key_users PRIMARY KEY (id)
)

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

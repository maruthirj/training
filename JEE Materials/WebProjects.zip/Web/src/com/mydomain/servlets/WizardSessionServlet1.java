package com.mydomain.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/WizardSessionServlet1")
public class WizardSessionServlet1 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		HttpSession session = request.getSession();
		session.setAttribute("name",name);
		session.setAttribute("address",address);
		request.getRequestDispatcher("jsp1.jsp").forward(request, response);
	}
}

//CODE in JSP1.jsp
//<form action='WizardSessionServlet2'>Phone: <input type='text' name='phone'/><br>
//Email: <input type='text' name='email'/><br>
//<input type='submit' value='finish'/></form>

//CODE in Servlet2
//String phone = request.getParameter("phone");
//String email = request.getParameter("email");
//request.setAttribute("email",email);
//request.getRequestDispatcher("jsp2.jsp").forward(request, response);


//CODE in JSP2.jsp
//Hello <%=session.getAttribute("name")%>, your email address is <%=request.getAttribute("email")%> 
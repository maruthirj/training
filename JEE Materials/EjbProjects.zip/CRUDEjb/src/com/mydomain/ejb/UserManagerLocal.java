package com.mydomain.ejb;

import java.util.List;
import java.util.concurrent.Future;

import javax.ejb.Local;

import com.mydomain.model.User;

@Local
public interface UserManagerLocal {

	public List<User> getAllUsers() throws Exception;
	
	public User getUser(Integer id) throws Exception;

	public void addUser(User u) throws Exception;

	public void updateUser(User u) throws Exception;

	public void deleteUser(Integer id) throws Exception;
	
	public void deleteUsers(List<Integer> ids) throws Exception;
	
	public void generateOrders() throws Exception;
	
	public void generateOrder(User u) throws Exception;
	
	public Future<Integer> generateOrdersAsync() throws Exception;
	
	public void transferUser(Integer id) throws Exception;
}

package com.mydomain.security;

import java.lang.reflect.Method;

/**
 * Proxy implementation that calls the original method by passing the security context info
 * @author maruthir
 *
 */
public class ClientProxyImpl implements java.lang.reflect.InvocationHandler {

	private Object obj;

	public static Object newInstance(Object obj) {
		if(!(obj instanceof AuthEnabler)){
			throw new IllegalArgumentException("This class can only proxy Auth Enabled classes");
		}
		return java.lang.reflect.Proxy.newProxyInstance(obj.getClass()
				.getClassLoader(), obj.getClass().getInterfaces(),
				new ClientProxyImpl(obj));
	}

	private ClientProxyImpl(Object obj) {
		this.obj = obj;
	}

	public Object invoke(Object proxy, Method m, Object[] args)
			throws Throwable {
		try {
			if(m.getName().equals("secureInvoke")){
				//This should never be called directly
				throw new IllegalStateException("Secure invoke should not be called on the client proxy directly. Call the target method");
			}else{
				//Grab auth info and call the secureInvoke method on the target
				String user = "admin";
				String pass = "admin123";
				return ((AuthEnabler)obj).secureInvoke(m, user, pass, args);
			}
		} catch (Exception e) {
			throw new RuntimeException("unexpected invocation exception: "
					+ e.getMessage());
		}
	}

}

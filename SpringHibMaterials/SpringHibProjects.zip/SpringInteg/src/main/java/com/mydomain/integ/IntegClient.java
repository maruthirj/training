package com.mydomain.integ;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mydomain.model.User;
import com.mydomain.service.UserManagerRemote;

public class IntegClient {

	private UserManagerRemote userManager;
	
	public UserManagerRemote getUserManager() {
		return userManager;
	}
	public void setUserManager(UserManagerRemote userManager) {
		this.userManager = userManager;
	}


	public static void main(String[] args) throws Exception{
		ApplicationContext context =
			    new ClassPathXmlApplicationContext(new String[] {"application-context.xml"});
		IntegClient client = (IntegClient)context.getBean("integClient");
		List<User> users = client.userManager.getAllUsers();
		System.out.println(users);

	}

}

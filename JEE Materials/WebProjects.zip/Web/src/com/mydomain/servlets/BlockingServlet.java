package com.mydomain.servlets;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BlockingServlet")
public class BlockingServlet extends HttpServlet {
	private AtomicInteger count = new AtomicInteger(0);
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int threadCount = count.incrementAndGet();
		System.out.println("Blocking servlet started in thread: "+threadCount);
		try {
			Thread.sleep(1000000);
		} catch (InterruptedException e) {}
	}

}

package com.mydomain.servlets;

import java.io.IOException;
import java.util.concurrent.Future;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydomain.ejb.UserManagerLocal;

@WebServlet("/GenerateOrdersServlet")
public class GenerateOrdersServlet extends HttpServlet {
	
	@EJB
	UserManagerLocal userManager;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			//userManager.generateOrders();
			Future<Integer> future = userManager.generateOrdersAsync();
			System.out.println("Fired order generation...");
			System.out.println("Number of users processed: "+future.get());
			response.sendRedirect("listServlet");
		}catch(Exception e){
			throw new ServletException(e);
		}
	}
}

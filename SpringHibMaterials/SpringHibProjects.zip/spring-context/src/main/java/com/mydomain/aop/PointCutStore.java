package com.mydomain.aop;

import org.aspectj.lang.annotation.Pointcut;

/**
 * Class to act as a store of pointcuts in our system
 * @author maruthir
 *
 */
public class PointCutStore {
	
	@Pointcut("execution(* getAll*(..))")// the pointcut expression
	public void allSecureMethods() {}// the pointcut signature
	
	@Pointcut("execution(* getAll*(..))")// the pointcut expression
	public void getAllMethods() {}// the pointcut signature

}

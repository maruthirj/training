package com.mydomain.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mydomain.model.User;


//@WebService(serviceName="UserManager")
public class UserManagerEndpoint {

	    @Autowired
	    private UserManager userManager;

		public User doesUserExist(String name) throws Exception{
			return userManager.doesUserExist(name);
	    }

		public List<User> getAllUsers() throws Exception{
			return userManager.getAllUsers();
		}
		
		public User getUser(Integer id) throws Exception{
			return userManager.getUser(id);
		}

		public void addUser(User u) throws Exception{
			userManager.addUser(u);
		}

		public void updateUser(User u) throws Exception{
			userManager.updateUser(u);
		}

		public void deleteUser(Integer id) throws Exception{
			userManager.deleteUser(id);
		}

}

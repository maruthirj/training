package com.mydomain.security;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.stereotype.Component;

@Component("authAdvice")
public class AuthAdvice implements MethodInterceptor{

	@Override
	public Object invoke(MethodInvocation mi) throws Throwable {
		System.out.println("Verifying authentication...");
        Object retVal = mi.proceed();
        return retVal;
    }
}

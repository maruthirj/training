package com.mydomain.controllers;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mydomain.model.User;
import com.mydomain.service.UserManager;
import com.mydomain.validator.UserValidator;

@Controller
public class UserController {
	
	@Autowired
	UserManager userManager;
	
	@InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(new UserValidator());
    }

	@RequestMapping("/userForm")
	public String showUserForm(HttpServletRequest req){
		return "UserForm";
	}
	
	@ModelAttribute("user")
	public User getUser(){
		return new User();
	}
	
	@ModelAttribute("ageList"  )
	public List<Integer> getAgeList(){
		System.out.println("getting ages list...");
		Integer[] ages = new Integer[]{18,19,20,21,22,23,24,25,26,27,28,29,30};
		return Arrays.asList(ages);
	}
	
    @RequestMapping("/addUser")
    public String addUser(@Valid User u, BindingResult bindingResult, Model model) throws Exception {
    	if (bindingResult.hasErrors()) {
    		System.out.println("Validation errors!");
            return "UserForm";
        }
    	userManager.addUser(u);
        model.addAttribute("message", "Added User!");
        return "helloWorld";
    }
    
    @RequestMapping("/listUsers")
    public String listUsers(Model model) throws Exception{
    	return "ListUsers";
    }
    
    @RequestMapping("/delete/{userId}")
    public String delete(@PathVariable int userId) throws Exception{
    	userManager.deleteUser(userId);
    	return "redirect:../listUsers";
    }
    
    @RequestMapping(value="/listUsersJson", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String listUsersJson() throws Exception{
    	List<User> users = userManager.getAllUsers();
    	String usersJson = JSONObject.valueToString(users);
    	return usersJson;
    }
    
    @RequestMapping("/genOrders")
    public String generateOrders(Model model) throws Exception{
    	System.out.println(userManager);
    	userManager.generateOrders();
    	model.addAttribute("message", "Orders Generated");
    	System.out.println("Done gen orders");
    	return "helloWorld";
    }
}
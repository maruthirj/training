package com.mydomain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class JDBCTx {
	public static void main(String[] args) throws Exception {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		Connection con = DriverManager.getConnection("jdbc:derby:mydb;create=true");
		Connection con2 = DriverManager.getConnection("jdbc:derby:mydb;create=true");
		con.setAutoCommit(false);
		con.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
		con2.setAutoCommit(false);
		Statement st = con.createStatement();
		Statement st2 = con2.createStatement();
		
		ResultSet rs = st.executeQuery("select * from students");
		printResultSet(rs);
			
		st2.executeUpdate("insert into students (name,address) values ('Ganesh','1 ABC Street ABC Bangalore')");
		
		ResultSet rs2 = st.executeQuery("select * from students");
		printResultSet(rs2);
		
		con.commit();
		con.close();
		con2.commit();
		con2.close();
		
	}
	
	private static void printResultSet(ResultSet rs) throws Exception{
		ResultSetMetaData meta = rs.getMetaData();
		int count = meta.getColumnCount();
		for(int i=1; i<= count; i++){
			System.out.print(meta.getColumnName(i)+" ");
		}
		System.out.println("\n-------------------------------------------");
		while(rs.next()){
			for(int i=1; i<= count; i++){
				System.out.print(rs.getString(i)+" ");
			}
			System.out.println("");
		}
	}
}

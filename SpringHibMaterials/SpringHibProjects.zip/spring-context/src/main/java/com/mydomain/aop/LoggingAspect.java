package com.mydomain.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {
	@Pointcut("execution(* getAll*(..))")// the pointcut expression
	public void getAllMethods() {}// the pointcut signature
	
	@Before( value="com.mydomain.aop.LoggingAspect.getAllMethods()")
    public void logMethodCallstart(JoinPoint joinPoint) {
		System.out.println("Executing before method: "+joinPoint.getSignature().getName());
    }
	
	@AfterReturning(returning="retVal", value="com.mydomain.aop.LoggingAspect.getAllMethods()")
    public void logMethodCallEnd(Object retVal) {
		System.out.println("returning Value: "+retVal);
    }
	
	@AfterThrowing(throwing="exception",value="com.mydomain.aop.LoggingAspect.getAllMethods()")
	public void logErrors(Throwable exception){
		System.out.println("Error happened: "+exception);
	}
	
	@Around("com.mydomain.aop.LoggingAspect.getAllMethods()")
    public Object doBasicProfiling(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.nanoTime();
        Object retVal = pjp.proceed();
        long end = System.nanoTime();
        System.out.println("Time taken(ms): "+(end-start)/1000);
        return retVal;
    }
}

package com.mydomain.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydomain.ejb.UserManagerLocal;
import com.mydomain.model.User;



@WebServlet("/AddEditServlet")
public class AddEditServlet extends HttpServlet {
	
	@EJB
	UserManagerLocal userManager;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			User u = new User();
			if(request.getParameter("id")!=null)
			u.setId(Integer.parseInt(request.getParameter("id")));
			u.setName(request.getParameter("name"));
			u.setAge(Integer.parseInt(request.getParameter("age")));
			if(u.getId()==null){
				userManager.addUser(u);	
			}else{
				userManager.updateUser(u);
			}
			response.sendRedirect("listServlet");
		}catch(Exception e){
			throw new ServletException(e);
		}
		
	}

}

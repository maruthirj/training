package com.mydomain.servlets;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FormProcessing
 */
@WebServlet("/FormProcessing")
public class FormProcessing extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Enumeration<String> paramNames = request.getParameterNames();
		while(paramNames.hasMoreElements()){
			String paramName = paramNames.nextElement();
			System.out.println("Parameter: "+paramName+" = "+request.getParameter(paramName));
		}
		request.getRequestDispatcher("thankyou.html").forward(request, response);
	}

}
